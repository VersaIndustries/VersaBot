import discord
import textwrap
import traceback
import inspect
import io
from contextlib import redirect_stdout
from discord.ext import commands
from jishaku.codeblocks import codeblock_converter
from Cogs.Utils.color import versacolors

transparent="ㅤ"
img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"

class eval(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    dev_acces = [1046141237511585903,677934345029156877]

    @commands.command(name='eval')
    async def _eval(self ,ctx, *, body):
        if ctx.author.id in self.dev_acces:
            """Evaluates python code"""
            env = {
                'ctx': ctx,
                'bot': self.bot,
                'channel': ctx.channel,
                'author': ctx.author,
                'guild': ctx.guild,
                'message': ctx.message,
                'source': inspect.getsource
            }

            def cleanup_code(content):
                """Automatically removes code blocks from the code."""
                if content.startswith('```py') and content.endswith('```'):
                    return '\n'.join(content.split('\n')[1:-1])

                return content.strip('` \n')

            def get_syntax_error(e):
                if e.text is None:
                    return f'```py\n{e.__class__.__name__}: {e}\n```'
                    return f'```py\n{e.text}{"^":>{e.offset}}\n{e.__class__.__name__}: {e}```'

            env.update(globals())

            body = cleanup_code(body)
            stdout = io.StringIO()
            err = out = None

            to_compile = f'async def func():\n{textwrap.indent(body, "  ")}'

            def paginate(text: str):
                '''Simple generator that paginates text.'''
                last = 0
                pages = []
                for curr in range(0, len(text)):
                    if curr % 1980 == 0:
                        pages.append(text[last:curr])
                        last = curr
                        appd_index = curr
                if appd_index != len(text) - 1:
                    pages.append(text[last:curr])
                return list(filter(lambda a: a != '', pages))

            try:
                exec(to_compile, env)
            except Exception as e:
                err = await ctx.send(f'```py\n{e.__class__.__name__}: {e}\n```')
                return await ctx.message.add_reaction('\u2049')

            func = env['func']
            try:
                with redirect_stdout(stdout):
                    ret = await func()
            except Exception as e:
                value = stdout.getvalue()
                err = await ctx.send(f'```py\n{value}{traceback.format_exc()}\n```')
            else:
                value = stdout.getvalue()
                if ret is None:
                    if value:
                        try:

                            out = await ctx.send(f'```py\n{value}\n```')
                        except:
                            paginated_text = paginate(value)
                            for page in paginated_text:
                                if page == paginated_text[-1]:
                                    out = await ctx.send(f'```py\n{page}\n```')
                                    break
                                await ctx.send(f'```py\n{page}\n```')
                else:
                    try:
                        out = await ctx.send(f'```py\n{value}{ret}\n```')
                    except:
                        paginated_text = paginate(f"{value}{ret}")
                        for page in paginated_text:
                            if page == paginated_text[-1]:
                                out = await ctx.send(f'```py\n{page}\n```')
                                break
                            await ctx.send(f'```py\n{page}\n```')

            if out:
                await ctx.message.add_reaction('\u2705')  # tick
            elif err:
                await ctx.message.add_reaction('\u2049')  # x
            else:
                await ctx.message.add_reaction('\u2705')
        else:
            embed2 = discord.Embed(color = discord.Colour.dark_red(),timestamp=ctx.message.created_at)
            embed2.set_footer(icon_url =img, text=f"{ctx.author.name} This command is only available to the bot developer\n VersaBot")
            await ctx.message.delete()
            await ctx.send(embed=embed2)

async def setup(bot):
      await bot.add_cog(eval(bot))
      print("-  " + versacolors.RED + "> " + versacolors.WHITE + "Developer Platform - eval | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)