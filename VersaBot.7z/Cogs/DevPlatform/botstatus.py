import discord
from discord.ext import commands
import json
from Cogs.Utils.color import versacolors

status_file = 'status.json'

transparent="ㅤ"
img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"


class botstatus(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    dev_acces = [1046141237511585903,677934345029156877]

    @commands.command()
    async def setstatus(self ,ctx, *, status):
        total_servers = len(self.bot.guilds)
        if ctx.author.id in self.dev_acces:
            with open(status_file, 'w') as file:
                file.write(json.dumps({'status': status}))
            status = status.replace("{total_servers}", str(total_servers))
            await self.bot.change_presence(activity=discord.Game(name=f"{status}"))
            await ctx.send(f'**>** Changed status to: {status}')
        else:
            embed2 = discord.Embed(color = discord.Colour.dark_red(),timestamp=ctx.message.created_at)
            embed2.set_footer(icon_url =img, text=f"{ctx.author.name} This command is only available to the bot developer\n VersaBot")
            await ctx.message.delete()
            await ctx.send(embed=embed2)

async def setup(bot):
      await bot.add_cog(botstatus(bot))
      print("-  " + versacolors.RED + "> " + versacolors.WHITE + "Developer Platform - Bot Status | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)