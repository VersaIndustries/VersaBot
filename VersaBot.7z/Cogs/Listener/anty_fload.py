import discord
from discord.ext import commands
from datetime import datetime
import datetime
from Cogs.Utils.color import versacolors

img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"

cooldown_mapping = commands.CooldownMapping.from_cooldown(10, 12.0, commands.BucketType.member)
def get_ratelimit(message: discord.Message):
    bucket = cooldown_mapping .get_bucket(message)
    return bucket.update_rate_limit()

class anty_fload(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    

    @commands.Cog.listener()
    async def on_message(self ,message):
        cursor = await self.bot.db.execute("SELECT vip_acc FROM main WHERE guild_id = ?", (message.guild.id,))
        vipacc = await cursor.fetchall()
        vipacc = vipacc[0]
        if vipacc[0] == "Yes":
            if ratelimit := get_ratelimit(message):
                await message.channel.purge(limit=10, check=lambda m: m.author.id == message.author.id)
                await message.author.edit(timed_out_until=(discord.utils.utcnow() + datetime.timedelta(hours=1)))
            

async def setup(bot):
      await bot.add_cog(anty_fload(bot))
      print("-  " + versacolors.PURPLE + "> " + versacolors.WHITE + "Listener - Anty Fload | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)