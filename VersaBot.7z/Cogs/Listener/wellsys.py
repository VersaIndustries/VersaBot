import discord
from discord.ext import commands
from discord import File
import os
from easy_pil import Editor, load_image_async, Font
from Cogs.Utils.color import versacolors

img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"

class WellSys(commands.Cog):
    def __init__(self, bot):
        self.bot = bot 

    @commands.Cog.listener()
    async def on_member_join(self, member):
        non_bot_members = [member for member in member.guild.members if not member.bot]
        total_users = len(non_bot_members)
        cursor = await self.bot.db.execute("SELECT vip_acc, join_channel_id, join_message FROM main WHERE guild_id = ?", (member.guild.id,))
        data = await cursor.fetchone()
        vip_acc, join_channel_id, join_message = data
        join_channel = member.guild.get_channel(join_channel_id)
        if vip_acc == "Yes":
            if join_message == "vip":
                current_dir = os.path.dirname(os.path.abspath(__file__))
                background = Editor(os.path.join(current_dir, "image//wellimg.png"))
                profile_image = await load_image_async(str(member.display_avatar))

                profile = Editor(profile_image).resize((150,150)).circle_image()
                poppins = Font.poppins(size=30, variant="bold")

                poppins_small= Font.poppins(size=20, variant="light")
                background.paste(profile, (325, 90))
                background.ellipse((325, 90), 150, 150, outline="white", stroke_width=5)

                background.text((400, 260), f"Welcome to {member.guild.name}", color="white", font=poppins, align="center")
                background.text((400, 325), f"{member.name} : {member.display_name}", color="white", font=poppins_small, align="center")
                background.text((400, 400), f"You are {total_users} person on the server", color="white", font=poppins_small, align="center")

                file = File(fp=background.image_bytes, filename="pic1.jpg")
                await join_channel.send(f"{member.mention}",file=file)
        else:
            join_message = join_message.replace("<member.mention>", member.mention).replace("<member.name>", member.name)
            embed = discord.Embed(title=f"Welcome to {member.guild.name}", description=join_message, color=discord.Colour.purple())
            embed.set_thumbnail(url = member.display_avatar)
            embed.set_footer(icon_url=img, text=f"VersaBot")
            join_channel = member.guild.get_channel(join_channel_id)
            if join_channel:
                await join_channel.send(embed=embed)

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        leave_channel = None
        cursor = await self.bot.db.execute("SELECT vip_acc, leave_channel_id, leave_message FROM main WHERE guild_id = ?", (member.guild.id,))
        data = await cursor.fetchone()
        vip_acc, leave_channel_id, leave_message = data
        if vip_acc == "Yes":
            if leave_message == "vip":
                current_dir = os.path.dirname(os.path.abspath(__file__))
                background = Editor(os.path.join(current_dir, "image//leavimg.png"))
                profile_image = await load_image_async(str(member.display_avatar))
                profile = Editor(profile_image).resize((150,150)).circle_image()
                poppins = Font.poppins(size=30, variant="bold")
                poppins_small= Font.poppins(size=20, variant="light")
                background.paste(profile, (325, 90))
                background.ellipse((325, 90), 150, 150, outline="white", stroke_width=5)
                background.text((400, 260), f"Goodbye from {member.guild.name}", color="white", font=poppins, align="center")
                background.text((400, 325), f"{member.name} : {member.display_name}", color="white", font=poppins_small, align="center")
                file = File(fp=background.image_bytes, filename="pic1.jpg")
                leave_channel = member.guild.get_channel(leave_channel_id)
                if leave_channel:
                    await leave_channel.send(f"{member.mention}", file=file)
            else:
                leave_channel_id, leave_message = data
                leave_message = leave_message.replace("<member.mention>", member.mention).replace("<member.name>", member.name)
                embed = discord.Embed(title="Leave", description=leave_message, color=discord.Colour.purple())
                embed.set_footer(icon_url=img, text=f"VersaBot")
                leave_channel = member.guild.get_channel(leave_channel_id)
                if leave_channel:
                    await leave_channel.send(embed=embed)


async def setup(bot):
      await bot.add_cog(WellSys(bot))
      print("-  " + versacolors.PURPLE + "> " + versacolors.WHITE + "Listener - WellSys | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)