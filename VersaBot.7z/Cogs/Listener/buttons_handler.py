import discord
from discord.ext import commands
from Cogs.Utils.color import versacolors


img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"

class button_handler(commands.Cog):
    def __init__(self, bot):
        self.bot = bot 

    @commands.Cog.listener("on_interaction")
    async def verification_handler(self, interaction):
        if not interaction.guild:
            return
        if custom_id := interaction.data.get("custom_id"):
            if custom_id == "verify":
                cursor = await self.bot.db.execute("SELECT Verify_role_id FROM main WHERE guild_id = ?", (interaction.guild.id,))
                role_id = await cursor.fetchone()
                rola = discord.utils.get(interaction.guild.roles, id=role_id[0])
                ver = discord.Embed(color = discord.Colour.purple())
                ver.set_footer(icon_url = img, text=f"You have been successfully verified \n VersaBot")
                await interaction.user.add_roles(rola)
                await interaction.response.send_message(embed=ver, ephemeral=True)


async def setup(bot):
      await bot.add_cog(button_handler(bot))
      print("-  " + versacolors.PURPLE + "> " + versacolors.WHITE + "Listener - ButtonsHandler | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)