import discord
from discord.ext import commands
from Cogs.Utils.color import versacolors
import random 
import base64
import string

img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"


class token(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def token(self, ctx, member: discord.Member):
        #---
        user_id = member.id
        user_id_bytes = str(user_id).encode('utf-8')
        base64_userid = base64.b64encode(user_id_bytes).decode('utf-8')
        #---
        time = int(ctx.message.created_at.timestamp())
        time_bytes = str(time).encode('utf-8')
        base64_time = base64.b64encode(time_bytes).decode('utf-8')
        #--
        random_letters = ''.join(random.choices(string.ascii_letters, k=20))
        random_digits = ''.join(random.choices(string.digits, k=7))
        generated_string = random_letters + random_digits
        generated_string = ''.join(random.sample(generated_string, len(generated_string)))

        embed = discord.Embed(title=f"{member.display_name}'s token:",color=discord.Colour.purple(),timestamp=ctx.message.created_at)
        embed.add_field(name="User id:", value=member.id)
        embed.add_field(name="Token:", value=f"{base64_userid}.{base64_time}.{generated_string}",inline=False)
        embed.set_footer(icon_url=img, text="VersaBot")
        await ctx.message.delete()
        await ctx.send(embed=embed)

async def setup(bot):
      await bot.add_cog(token(bot))
      print("-  " + versacolors.CYAN + "> " + versacolors.WHITE + "Command 4FUN - Token | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)