import discord
from discord.ext import commands
from Cogs.Utils.color import versacolors
import random 

img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"


class ip(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def ip(self, ctx, member: discord.Member):
        one = random.randint(10, 255)
        two = random.randint(10, 255)
        three = random.randint(10, 255)
        four = random.randint(10, 255)
        await ctx.message.delete()
        embed = discord.Embed(title=f"{member.display_name} ip:", description=f"{one}.{two}.{three}.{four}", color=discord.Colour.purple(), timestamp=ctx.message.created_at)
        embed.set_footer(icon_url=img,text="VersaBot")
        await ctx.send(embed=embed)

async def setup(bot):
      await bot.add_cog(ip(bot))
      print("-  " + versacolors.CYAN + "> " + versacolors.WHITE + "Command 4FUN - Ip | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)