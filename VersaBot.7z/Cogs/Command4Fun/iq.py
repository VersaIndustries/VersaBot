import discord
from discord.ext import commands
from Cogs.Utils.color import versacolors
import random 

img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"


class iq(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def iq(self, ctx, member: discord.Member = None):
        await ctx.message.delete()
        random_number = random.randint(0, 295)
        if member == None:
            embed = discord.Embed(description=f"``{ctx.author.display_name}`` has **{random_number}** iq", color=discord.Colour.purple(),timestamp=ctx.message.created_at)
            embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/1199467928958029877/1208385433860313168/smart-think_1.gif?ex=65e317a2&is=65d0a2a2&hm=0c5b98a06f93d74b3b11ca1128f377f4cc509c33a8f0caac90f2746a8abe0303&")
            embed.set_footer(icon_url=img, text='VersaBot')
            await ctx.send(embed=embed)
        else:
            embed = discord.Embed(description=f"``{member.display_name}`` has **{random_number}** iq", color=discord.Colour.purple(), timestamp=ctx.message.created_at)
            embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/1199467928958029877/1208385433860313168/smart-think_1.gif?ex=65e317a2&is=65d0a2a2&hm=0c5b98a06f93d74b3b11ca1128f377f4cc509c33a8f0caac90f2746a8abe0303&")
            embed.set_footer(icon_url=img, text='VersaBot')
            await ctx.send(embed=embed)
async def setup(bot):
      await bot.add_cog(iq(bot))
      print("-  " + versacolors.CYAN + "> " + versacolors.WHITE + "Command 4FUN - Iq | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)