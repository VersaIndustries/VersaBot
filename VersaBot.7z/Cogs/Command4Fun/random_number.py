import discord
from discord.ext import commands
from Cogs.Utils.color import versacolors
import random 

img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"


class randomnumber(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def number(self, ctx):
        pierwsze = random.randint(100, 999)
        drugie = random.randint(100, 999)
        trzecie = random.randint(100, 999)
        embed = discord.Embed(title="Random phone number", description=f"**+48** ``{pierwsze}``-``{drugie}``-``{trzecie}``", color=discord.Colour.purple(),timestamp=ctx.message.created_at)
        embed.set_footer(icon_url=img, text="VersaBot")
        await ctx.send(embed=embed)
async def setup(bot):
      await bot.add_cog(randomnumber(bot))
      print("-  " + versacolors.CYAN + "> " + versacolors.WHITE + "Command 4FUN - Random Number | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)