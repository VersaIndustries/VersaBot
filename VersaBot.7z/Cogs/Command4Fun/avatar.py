import discord
from discord.ext import commands
from Cogs.Utils.color import versacolors

img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"


class avatar(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def avatar(self, ctx, member: discord.Member):
        await ctx.message.delete()
        userAvatar = member.display_avatar
        embed = discord.Embed(description=f"**User avatar:** {member.mention} [``{member.name}``]",color=discord.Colour.purple(), timestamp=ctx.message.created_at)
        embed.set_image(url=userAvatar)
        embed.set_footer(icon_url=img, text="VersaBot")
        await ctx.send(embed=embed)

async def setup(bot):
      await bot.add_cog(avatar(bot))
      print("-  " + versacolors.CYAN + "> " + versacolors.WHITE + "Command 4FUN - avatar | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)