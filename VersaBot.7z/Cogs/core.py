from discord.ext import commands
from Cogs.Utils.color import versacolors

class Core(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        

    async def load_all_extensions(self):
        #command

        
        try:
            await self.bot.load_extension("Cogs.Command.help")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - Help | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command.about")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - About | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command.setperms")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - SetPerms | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command.ban")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - Ban | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command.kick")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - Kick | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command.wellsyscmd")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - WellSysCmd | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")
         #-
        try:
            await self.bot.load_extension("Cogs.Command.embed")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - Embed | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command.vipsetcmd")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - VipSetCmd | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command.clear")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - Clear | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command.poll")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - Poll | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command.warn")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - Warn | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command.whitelistcmd")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - WhtelistCmd | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command.verify_role")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - VerifyRole | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command.verify_button")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - Verify | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command.setlogs")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - SetLogs | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command.chl")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - ChangeLog | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command.statscmd")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command - Stats cmd | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(e)
            print("------\n")

        #listeners
            
        try:
            await self.bot.load_extension("Cogs.Listener.whitelist")
        except Exception as e:
            print(versacolors.PURPLE + "> " + versacolors.WHITE + "Listener - whitelist | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(versacolors.RED + f"Error: {e}" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Listener.wellsys")
        except Exception as e:
            print(versacolors.PURPLE + "> " + versacolors.WHITE + "Listener - WellSys | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(versacolors.RED + f"Error: {e}" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Listener.buttons_handler")
        except Exception as e:
            print(versacolors.PURPLE + "> " + versacolors.WHITE + "Listener - ButtonsHandler | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(versacolors.RED + f"Error: {e}" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Listener.anty_fload")
        except Exception as e:
            print(versacolors.PURPLE + "> " + versacolors.WHITE + "Listener - Anty Fload | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(versacolors.RED + f"Error: {e}" + versacolors.WHITE)
            print(e)
            print("------\n")


        #task
        try:
            await self.bot.load_extension("Cogs.Tasks.status_task")
        except Exception as e:
            print(versacolors.PURPLE + "> " + versacolors.DARK_YELLOW + "Task - Status task | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(versacolors.RED + f"Error: {e}" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Tasks.stats_task")
        except Exception as e:
            print(versacolors.PURPLE + "> " + versacolors.DARK_YELLOW + "Task - Stats task | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(versacolors.RED + f"Error: {e}" + versacolors.WHITE)
            print(e)
            print("------\n")

        #4FUN command
        try:
            await self.bot.load_extension("Cogs.Command4Fun.avatar")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command 4FUN - avatar | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(versacolors.RED + f"Error: {e}" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command4Fun.iq")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command 4FUN - Iq | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(versacolors.RED + f"Error: {e}" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command4Fun.random_number")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command 4FUN - Random Number | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(versacolors.RED + f"Error: {e}" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command4Fun.ip")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command 4FUN - Ip | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(versacolors.RED + f"Error: {e}" + versacolors.WHITE)
            print(e)
            print("------\n")
        #-
        try:
            await self.bot.load_extension("Cogs.Command4Fun.token")
        except Exception as e:
            print(versacolors.BLUE + "> " + versacolors.WHITE + "Command 4FUN - Token | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(versacolors.RED + f"Error: {e}" + versacolors.WHITE)
            print(e)
            print("------\n")

        #devcmd
        
        try:
            await self.bot.load_extension("Cogs.DevPlatform.eval")
        except Exception as e:
            print(versacolors.RED + "> " + versacolors.WHITE + "Developer platform - eval | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(versacolors.RED + f"Error: {e}" + versacolors.WHITE)
            print(e)
            print("------\n")
        try:
            await self.bot.load_extension("Cogs.DevPlatform.botstatus")
        except Exception as e:
            print(versacolors.RED + "> " + versacolors.WHITE + "Developer platform - Bot status | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
            print(versacolors.RED + f"Error: {e}" + versacolors.WHITE)
            print(e)
            print("------\n")

async def setup(bot):
    print(versacolors.CYAN + "> " + versacolors.WHITE + "Module - Core: ")
    core_cog = Core(bot)
    await core_cog.load_all_extensions()
    await bot.add_cog(core_cog)
