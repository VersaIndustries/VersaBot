from discord.ext import commands
from discord.ext import tasks
from Cogs.Utils.color import versacolors

img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"

class statstask(commands.Cog):
    def __init__(self, bot):
        self.bot = bot 
        self.stats_task.start()

    @tasks.loop(minutes=5)
    async def stats_task(self):
        for guild in self.bot.guilds:
            cursor = await self.bot.db.execute("SELECT stats_channel_id, stats_channel_text FROM main WHERE guild_id = ?", (guild.id,))
            data = await cursor.fetchone()
            if data is not None:
                stats_channel_id, stats_channel_text = data
                voice_channel = guild.get_channel(stats_channel_id)
                if voice_channel:
                    non_bot_members = [member for member in guild.members if not member.bot]
                    total_users = len(non_bot_members)
                    await voice_channel.edit(name=f"{stats_channel_text} {total_users}")


async def setup(bot):
      await bot.add_cog(statstask(bot))
      print("-  " + versacolors.DARK_YELLOW + "> " + versacolors.WHITE + "Task - Stats Task | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)