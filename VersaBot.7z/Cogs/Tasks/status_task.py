import discord
from discord.ext import commands
from discord.ext import tasks
import json
from Cogs.Utils.color import versacolors

img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"
status_file = "status.json"

class statustask(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.status_task.start()

    @tasks.loop(minutes=5)
    async def status_task(self):
        with open(status_file, 'r') as file:
            status_data = json.load(file)
            await self.bot.change_presence(activity=discord.Game(name=status_data['status'].replace("{total_servers}", str(len(self.bot.guilds)))))

async def setup(bot):
      await bot.add_cog(statustask(bot))
      print("-  " + versacolors.DARK_YELLOW + "> " + versacolors.WHITE + "Task - Status Task | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)