import discord
from discord.ext import commands
from Cogs.Utils.color import versacolors

dev_acces = 1046141237511585903
img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"

class chl(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    dev_acces = 1046141237511585903

    #ini
    @commands.command()
    async def chl(self, ctx, *, message):
        if ctx.author.id == self.dev_acces:
            embed = discord.Embed(description=f"```Elm\n[Change-Log]```\n \n{message}",color=discord.Colour.purple(), timestamp=ctx.message.created_at)
            embed.set_footer(icon_url=img,text="VersaBot")
            await ctx.message.delete()
            await ctx.send(embed=embed)
        else:
            embed2 = discord.Embed(color = discord.Colour.dark_red(),timestamp=ctx.message.created_at)
            embed2.set_footer(icon_url =img, text=f"{ctx.author.name} This command is only available to the bot developer\n VersaBot")
            await ctx.message.delete()
            await ctx.send(embed=embed2)
            
async def setup(bot):
      await bot.add_cog(chl(bot))
      print("-  " + versacolors.BLUE + "> " + versacolors.WHITE + "Command - Changelog | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)