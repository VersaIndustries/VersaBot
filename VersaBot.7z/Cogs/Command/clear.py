import discord
from discord.ext import commands
import asyncio
from Cogs.Utils.color import versacolors

dev_acces = 1046141237511585903
img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"

class clear(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def clear(self, ctx, amount = "None"):
        await ctx.message.delete()
        cursor = await self.bot.db.execute("SELECT clear_id FROM main WHERE guild_id = ?", (ctx.guild.id,))
        role_id = await cursor.fetchone()
        rola = discord.utils.get(ctx.guild.roles, id=role_id[0])
        if rola in ctx.author.roles:
            if amount == "all":
                await ctx.channel.purge(limit=None)
                em = discord.Embed(title="Clear",colour=discord.Colour.purple(),timestamp=ctx.message.created_at)
                em.add_field(name="Admin:",value=ctx.message.author.mention)
                em.add_field(name=f"Deleted message",value="``all``", inline=False)
                em.set_footer(icon_url = img, text=f"VersaBot")
                emmsg = await ctx.send(embed=em)
                log = discord.Embed(title="Log",color=discord.Colour.purple(), timestamp=ctx.message.created_at)
                log.add_field(name="Author:", value=f"{ctx.author.mention} [``{ctx.author.name}``]")
                log.add_field(name="Command:",value=f"*clear ``all``")
                log.add_field(name="Channel:", value=ctx.channel.mention)
                log.set_footer(icon_url=img,text="VersaBot")
                cursor = await self.bot.db.execute("SELECT logs_channel_id FROM main WHERE guild_id = ?", (ctx.guild.id,))
                data = await cursor.fetchone()
                channel = ctx.guild.get_channel(data[0])
                await channel.send(embed=log)
                await asyncio.sleep(15)
                await emmsg.delete()
            else:
                deleted = await ctx.channel.purge(limit=int(amount))
                em = discord.Embed(title="Clear",colour=discord.Colour.purple(),timestamp=ctx.message.created_at)
                em.add_field(name="Admin:",value=ctx.message.author.mention)
                em.add_field(name=f"Deleted message",value=f"``{len(deleted)}``", inline=False)
                em.set_footer(icon_url = img, text=f"VersaBot")
                emmsg = await ctx.send(embed=em)
                log = discord.Embed(title="Log",color=discord.Colour.purple(), timestamp=ctx.message.created_at)
                log.add_field(name="Author:", value=f"{ctx.author.mention} [``{ctx.author.name}``]")
                log.add_field(name="Command:",value=f"*clear ``{amount}``")
                log.add_field(name="Channel:", value=ctx.channel.mention)
                log.set_footer(icon_url=img,text="VersaBot")
                cursor = await self.bot.db.execute("SELECT logs_channel_id FROM main WHERE guild_id = ?", (ctx.guild.id,))
                data = await cursor.fetchone()
                channel = ctx.guild.get_channel(data[0])
                await channel.send(embed=log)
                await asyncio.sleep(15)
                await emmsg.delete()
        else:
            embed2 = discord.Embed(description=f"**>** You do not have access to this command",color = discord.Colour.purple(),timestamp=ctx.message.created_at)
            embed2.set_footer(icon_url =img, text=f"VersaBot > {ctx.author}")
            await ctx.send(embed=embed2)
            
async def setup(bot):
      await bot.add_cog(clear(bot))
      print("-  " + versacolors.BLUE + "> " + versacolors.WHITE + "Command - Clear | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)