import discord
from discord.ext import commands
import typing
from Cogs.Utils.color import versacolors

dev_acces = 1046141237511585903
img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"


class setperms(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def permission(self, ctx, type: typing.Optional[str], role: discord.Role):
        if type == "ban":
            await self.bot.db.execute(
                """
                UPDATE main SET ban_id = ? WHERE guild_id = ?;
                """,
                (role.id, ctx.guild.id)
            )
            await self.bot.db.commit()
            embed = discord.Embed(
                    title="🔒 Permissions have been set:",
                    color=discord.Colour.purple(),
                    timestamp=ctx.message.created_at
                    )
            embed.add_field(name="Command:",value=type)
            embed.add_field(name="Role:",value=f"{role.mention} ( **{role.id}** )")
            embed.set_footer(icon_url=img, text=f"VersaBot")
            await ctx.message.delete()
            await ctx.send(embed=embed)
        elif type == "kick":
            await self.bot.db.execute(
                """
                UPDATE main SET kick_id = ? WHERE guild_id = ?;
                """,
                (role.id, ctx.guild.id)
            )
            await self.bot.db.commit()
            embed = discord.Embed(
                    title="🔒 Permissions have been set:",
                    color=discord.Colour.purple(),
                    timestamp=ctx.message.created_at
                    )
            embed.add_field(name="Command:",value=type)
            embed.add_field(name="Role:",value=f"{role.mention} ( **{role.id}** )")
            embed.set_footer(icon_url=img, text=f"VersaBot")
            await ctx.message.delete()
            await ctx.send(embed=embed)
        elif type == "clear":
            await self.bot.db.execute(
                """
                UPDATE main SET clear_id = ? WHERE guild_id = ?;
                """,
                (role.id, ctx.guild.id)
            )
            await self.bot.db.commit()
            embed = discord.Embed(
                    title="🔒 Permissions have been set:",
                    color=discord.Colour.purple(),
                    timestamp=ctx.message.created_at
                    )
            embed.add_field(name="Command:",value=type)
            embed.add_field(name="Role:",value=f"{role.mention} ( **{role.id}** )")
            embed.set_footer(icon_url=img, text=f"VersaBot")
            await ctx.message.delete()
            await ctx.send(embed=embed)
        elif type == "warn":
            await self.bot.db.execute(
                """
                UPDATE main SET warn_id = ? WHERE guild_id = ?;
                """,
                (role.id, ctx.guild.id)
            )
            await self.bot.db.commit()
            embed = discord.Embed(
                    title="🔒 Permissions have been set:",
                    color=discord.Colour.purple(),
                    timestamp=ctx.message.created_at
                    )
            embed.add_field(name="Command:",value=type)
            embed.add_field(name="Role:",value=f"{role.mention} ( **{role.id}** )")
            embed.set_footer(icon_url=img, text=f"VersaBot")
            await ctx.message.delete()
            await ctx.send(embed=embed)
        elif type == "poll":
            await self.bot.db.execute(
                """
                UPDATE main SET poll_id = ? WHERE guild_id = ?;
                """,
                (role.id, ctx.guild.id)
            )
            await self.bot.db.commit()
            embed = discord.Embed(
                    title="🔒 Permissions have been set:",
                    color=discord.Colour.purple(),
                    timestamp=ctx.message.created_at
                    )
            embed.add_field(name="Command:",value=type)
            embed.add_field(name="Role:",value=f"{role.mention} ( **{role.id}** )")
            embed.set_footer(icon_url=img, text=f"VersaBot")
            await ctx.message.delete()
            await ctx.send(embed=embed)
        elif type == "embed":
            await self.bot.db.execute(
                """
                UPDATE main SET embed_id = ? WHERE guild_id = ?;
                """,
                (role.id, ctx.guild.id)
            )
            await self.bot.db.commit()
            embed = discord.Embed(
                    title="🔒 Permissions have been set:",
                    color=discord.Colour.purple(),
                    timestamp=ctx.message.created_at
                    )
            embed.add_field(name="Command:",value=type)
            embed.add_field(name="Role:",value=f"{role.mention} ( **{role.id}** )")
            embed.set_footer(icon_url=img, text=f"VersaBot")
            await ctx.message.delete()
            await ctx.send(embed=embed)

async def setup(bot):
      await bot.add_cog(setperms(bot))
      print("-  " + versacolors.BLUE + "> " + versacolors.WHITE + "Command - SetPerms | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)