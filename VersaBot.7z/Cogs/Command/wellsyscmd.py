import discord
from discord.ext import commands
import typing
from Cogs.Utils.color import versacolors


img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"

class wellsyscmd(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def wellset(self, ctx, type: typing.Optional[str], channel: discord.TextChannel, *, message):
        if type == "join":
            await self.bot.db.execute(
                """
                UPDATE main SET join_channel_id = ? WHERE guild_id = ?;
                """,
                (channel.id, ctx.guild.id)
            )
            await self.bot.db.execute(
                """
                UPDATE main SET join_message = ? WHERE guild_id = ?;
                """,
                (message, ctx.guild.id)
            )
            await self.bot.db.commit()
            embed = discord.Embed(
                    title="➕ Join sys have been set:",
                    color=discord.Colour.purple(),
                    timestamp=ctx.message.created_at
                    )
            embed.add_field(name="Channel:",value=f"{channel.mention} [ {channel.name} ]")
            embed.add_field(name="Message:",value=f"```{message}```",inline=False)
            embed.set_footer(icon_url=img, text=f"VersaBot")
            await ctx.message.delete()
            await ctx.send(embed=embed)
        elif type == "leave":
            await self.bot.db.execute(
                """
                UPDATE main SET leave_channel_id = ? WHERE guild_id = ?;
                """,
                (channel.id, ctx.guild.id)
            )
            await self.bot.db.execute(
                """
                UPDATE main SET leave_message = ? WHERE guild_id = ?;
                """,
                (message, ctx.guild.id)
            )
            await self.bot.db.commit()
            embed = discord.Embed(
                    title="➖ Leave sys have been set:",
                    color=discord.Colour.purple(),
                    timestamp=ctx.message.created_at
                    )
            embed.add_field(name="Channel:",value=f"{channel.mention} [ {channel.name} ]")
            embed.add_field(name="Message:",value=f"```{message}```",inline=False)
            embed.set_footer(icon_url=img, text=f"VersaBot")
            await ctx.message.delete()
            await ctx.send(embed=embed)

async def setup(bot):
      await bot.add_cog(wellsyscmd(bot))
      print("-  " + versacolors.BLUE + "> " + versacolors.WHITE + "Command - WellSysCmd | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)