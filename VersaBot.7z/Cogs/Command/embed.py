import discord
from discord.ext import commands
from Cogs.Utils.color import versacolors

dev_acces = 1046141237511585903
img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"

class embed(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def embed(self, ctx, title="", *,message=""):
        await ctx.message.delete()
        cursor = await self.bot.db.execute("SELECT embed_id FROM main WHERE guild_id = ?", (ctx.guild.id,))
        role_id = await cursor.fetchone()
        rola = discord.utils.get(ctx.guild.roles, id=role_id[0])
        if rola in ctx.author.roles:
            if title == "" and message == "":
                await ctx.send('Correct usage: *embed <"title"> <message>')
            embed = discord.Embed(title=title, description=message,color=discord.Colour.purple(), timestamp=ctx.message.created_at)
            embed.set_footer(icon_url=img, text=f"VersaBot")
            await ctx.send(embed=embed)
        else:
            embed2 = discord.Embed(description=f"**>** You do not have access to this command",color = discord.Colour.purple(),timestamp=ctx.message.created_at)
            embed2.set_footer(icon_url =img, text=f"VersaBot")
            await ctx.send(embed=embed2)
            
async def setup(bot):
      await bot.add_cog(embed(bot))
      print("-  " + versacolors.BLUE + "> " + versacolors.WHITE + "Command - Embed | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)