import discord
from discord.ext import commands
import typing
from Cogs.Utils.color import versacolors

img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"

class wwhitelistcmd(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    dev_acces = [1046141237511585903,677934345029156877]

    @commands.command()
    async def whitelist(self, ctx, opt: typing.Optional[str], id=None):
        if ctx.author.id in self.dev_acces:
            vipacc_status = "No"
            if opt == "add":
                await self.bot.db.execute("INSERT OR IGNORE INTO main (guild_id, vip_acc, ban_id, kick_id, clear_id, warn_id, poll_id, embed_id, join_channel_id, leave_channel_id, join_message, leave_message, verify_role_id) VALUES (?, ?, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)", (id, vipacc_status,))
                await self.bot.db.commit()
                embed = discord.Embed(
                    title="💾 Added server to whitelist",
                    color=discord.Colour.purple(),
                    timestamp=ctx.message.created_at
                    )
                embed.add_field(name="Admin:",value=ctx.author.display_name)
                embed.add_field(name="Server id:",value=id)
                embed.set_footer(icon_url=img, text=f"VersaBot")
                await ctx.message.delete()
                await ctx.send(embed=embed)
            if opt == "remove":
                await self.bot.db.execute("DELETE FROM main WHERE guild_id = ?", (id,))
                await self.bot.db.commit()
                embed = discord.Embed(
                    title="💾 Remove server from whitelist",
                    color=discord.Colour.purple(),
                    timestamp=ctx.message.created_at
                    )
                embed.add_field(name="Admin:",value=ctx.author.display_name)
                embed.add_field(name="Server id:",value=id)
                embed.set_footer(icon_url=img, text=f"VersaBot")
                await ctx.message.delete()
                await ctx.send(embed=embed)
                guild_leave = await self.bot.fetch_guild(id)
                await guild_leave.leave()
            if opt == "list":
                cursor = await self.bot.db.execute("SELECT guild_id FROM main")
                wllist = await cursor.fetchall()
                if wllist:
                    guild_ids = [row[0] for row in wllist]
                    guild_ids_str = "\n".join(map(str, guild_ids))
                    embed = discord.Embed(title="📖 Guild ID in Database", description=guild_ids_str, color=discord.Colour.purple(),timestamp=ctx.message.created_at)
                    embed.set_footer(icon_url=img, text=f"VersaBot")
                    await ctx.message.delete()
                    await ctx.send(embed=embed)
                else:
                    embed = discord.Embed(title="📘 No Records in Database", description="There are no records in the database.", color=discord.Colour.purple())
                    embed.set_footer(icon_url=img, text=f"VersaBot")
                    await ctx.message.delete()
                    await ctx.send(embed=embed)
            if opt == "lookup":
                cursor = await self.bot.db.execute("SELECT vip_acc FROM main WHERE guild_id = ?", (id,))
                vipacc = await cursor.fetchall()
                vipacc = vipacc[0]
                guild = await self.bot.fetch_guild(id)
                owner = await self.bot.fetch_user(guild.owner_id)
                guild_name = guild.name
                owner_name = f"{owner.display_name}:{owner.name}"
                lookup=discord.Embed(title="📋 Server id lookup:", color=discord.Colour.dark_purple(),timestamp=ctx.message.created_at)
                lookup.add_field(name="Id:", value=id)
                lookup.add_field(name="Guild name:",value=guild_name, inline=False)
                lookup.add_field(name="Owner:",value=f"{owner_name}")
                if vipacc:
                    lookup.add_field(name="Vip:", value=f"{vipacc[0]}")
                lookup.set_footer(icon_url=img, text=f"VersaBot")
                await ctx.message.delete()
                await ctx.send(embed=lookup)
            if opt == "check":
                await ctx.message.delete()
                cursor = await self.bot.db.execute("SELECT guild_id FROM main")
                wllist = [i[0] for i  in await cursor.fetchall()]
                ilosc = 0
                for guild in self.bot.guilds:
                    if guild.id not in wllist:
                        await guild.leave()
                        ilosc += 1
                if ilosc == 0:
                    await ctx.send("The bot has not left any server")
                else:
                    await ctx.send(f"The bot left {ilosc} of servers because they were not on the whitelist.")
        else:
            embed2 = discord.Embed(color = discord.Colour.dark_red(),timestamp=ctx.message.created_at)
            embed2.set_footer(icon_url =img, text=f"{ctx.author.name} This command is only available to the bot developer\n VersaBot")
            await ctx.message.delete()
            await ctx.send(embed=embed2)

async def setup(bot):
      await bot.add_cog(wwhitelistcmd(bot))
      print("-  " + versacolors.BLUE + "> " + versacolors.WHITE + "Command - WhitelistCmd | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)