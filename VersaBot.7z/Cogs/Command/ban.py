import discord
from discord.ext import commands
from Cogs.Utils.color import versacolors

img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"

class ban(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def ban (self,ctx, member: discord.Member, reason = None):
        cursor = await self.bot.db.execute("SELECT ban_id FROM main WHERE guild_id = ?", (ctx.guild.id,))
        role_id = await cursor.fetchone()
        rola = discord.utils.get(ctx.guild.roles, id=role_id[0])
        if rola in ctx.author.roles:
            embed = discord.Embed(title="Ban", colour=discord.Colour.blue(), timestamp=ctx.message.created_at)
            embed.add_field(name="Admin:",value=ctx.author.name)
            embed.add_field(name="User:",value=member.name)
            embed.add_field(name="Reason:",value=f"\n```{reason}```", inline=False)
            embed.set_thumbnail(url = "https://cdn.discordapp.com/attachments/901031229573451797/934407524856238080/ban-banned.gif")
            embed.set_footer(icon_url=img, text=f"VersaBot")
            if member == "None":
                await ctx.send(f"{ctx.author.mention} You did not specify a user")
            if member.id == ctx.author.id:
                await ctx.send(f"{ctx.author.mention} You can't ban yourself")
            else:
                await member.ban(reason=reason)
                await ctx.send(embed=embed)
                log = discord.Embed(title="Log",color=discord.Colour.purple(), timestamp=ctx.message.created_at)
                log.add_field(name="Author:", value=f"{ctx.author.mention} [``{ctx.author.name}``]")
                log.add_field(name="Command:",value=f"*ban {member.mention} [``{member.name}``] {reason}")
                log.set_footer(icon_url=img,text="VersaBot")
                cursor = await self.bot.db.execute("SELECT logs_channel_id FROM main WHERE guild_id = ?", (ctx.guild.id,))
                data = await cursor.fetchone()
                channel = ctx.guild.get_channel(data[0])
                await channel.send(embed=log)
        else:
            embed2 = discord.Embed(description=f"**>** You do not have access to this command",color = discord.Colour.purple(),timestamp=ctx.message.created_at)
            embed2.set_footer(icon_url =img, text=f"VersaBot > {ctx.author}")
            await ctx.send(embed=embed2)

async def setup(bot):
      await bot.add_cog(ban(bot))
      print("-  " + versacolors.BLUE + "> " + versacolors.WHITE + "Command - Ban | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)