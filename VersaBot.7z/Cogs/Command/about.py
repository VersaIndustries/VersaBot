import discord
from discord.ext import commands
import psutil
from datetime import datetime
from Cogs.Utils.color import versacolors
import humanize

img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"
transparent="ㅤ"

class about(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def about(self, ctx):
        await ctx.message.delete()
        delta_uptime = datetime.utcnow() - self.bot.launch_time
        hours, remainder = divmod(int(delta_uptime.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        days, hours = divmod(hours, 24)
        about = discord.Embed(color=discord.Colour.purple(), timestamp=ctx.message.created_at)
        total_ram = psutil.virtual_memory().total
        used_ram = psutil.virtual_memory().used
        free_ram = psutil.virtual_memory().free
        f_total_ram = humanize.naturalsize(total_ram)
        f_used_ram = humanize.naturalsize(used_ram)
        f_free_ram = humanize.naturalsize(free_ram)
        about.description=(
             #versa logo
             "```ansi\n\u001b[0;34m      __      __                       ____        _        \n" +
             "      \ \    / /                      |  _ \      | |       \n" +
             "       \ \  / /__ _ __ ___  __ _      | |_) | ___ | |_      \n" +
             "        \ \/ / _ \ '__/ __|/ _` |     |  _ < / _ \| __|     \n" +
             "         \  /  __/ |  \__ \ (_| |     | |_) | (_) | |_      \n" +
             "          \/ \___|_|  |___/\__,_|     |____/ \___/ \__|     ```" +

             #server info
             f"```ansi\n\u001b[0;41mSERVER INFO\u001b[0;0m" + f"\n├── \u001b[0;32m{days}d, {hours}h, {minutes}m \u001b[0;45mUPTIME\u001b[0;0m" + f"\n├── \u001b[0;32mAMD Ryzen 9 5950X \u001b[0;45mCPU MODEL\u001b[0;0m" + f"\n├── \u001b[0;32m{psutil.cpu_percent()}% \u001b[0;45mCPU USAGE\u001b[0;0m" + f"\n├── \u001b[0;32m{f_total_ram} \u001b[0;45mTOTAL RAM\u001b[0;0m" + f"\n├── \u001b[0;32m{f_free_ram} \u001b[0;45mFREE RAM\u001b[0;0m" +f"\n└── \u001b[0;32m{f_used_ram} \u001b[0;45mUSED RAM\u001b[0;0m"+ "```" +
             #-
             " " +
            #Bot environment
            f"```ansi\n\u001b[0;41mPYTHON\u001b[0;0m\n└──\u001b[0;32m 3.10\u001b[0;0m" + "\n\u001b[0;41mDISCORD.PY\u001b[0;0m\n└──\u001b[0;32m 2.3.2\u001b[0;0m" + "```" +
            #-
            " " +
            #Bot dev info
            f"```ansi\n\u001b[0;41mBOT DEVELOPER's\u001b[0;0m" + "\n├──\u001b[0;32m 3DV \u001b[0;45mMAIN DEVELOPER\u001b[0;0m" + "\n├──\u001b[0;32m zamrazarka__ \u001b[0;45mDEVELOPER\u001b[0;0m" + "\n└──\u001b[0;32m mesik \u001b[0;45mSUPPORT DEVELOPER\u001b[0;0m" + "```"
            )
        about.set_footer(icon_url=img, text=f"VersaBot")
        await ctx.send(embed=about)

async def setup(bot):
      await bot.add_cog(about(bot))
      print("-  " + versacolors.BLUE + "> " + versacolors.WHITE + "Command - About | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)