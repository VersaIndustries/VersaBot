import discord
from discord.ext import commands
from Cogs.Utils.color import versacolors

img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"


class warn(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def warn(self, ctx, member: discord.Member, *,reason = "None"):
        await ctx.message.delete()
        cursor = await self.bot.db.execute("SELECT warn_id FROM main WHERE guild_id = ?", (ctx.guild.id,))
        role_id = await cursor.fetchone()
        rola = discord.utils.get(ctx.guild.roles, id=role_id[0])
        if rola in ctx.author.roles:
            if reason == "None":
                await ctx.send("Correct usage: *warn <user> <reason>")
            else:
                embed = discord.Embed(title=f"Warn", color=discord.Colour.purple(), timestamp=ctx.message.created_at)
                embed.add_field(name="Server:", value=ctx.guild.name)
                embed.add_field(name="Admin:", value=f"{ctx.author.mention} [``{ctx.author.name}``]")
                embed.add_field(name="User:", value=f"{member.mention} [``{member.name}``]")
                embed.add_field(name="Reason:", value=f"```{reason}```", inline=False)
                embed.set_thumbnail(url=ctx.guild.icon.url)
                embed.set_footer(icon_url=img, text="VersaBot")
                await member.send(embed=embed)
                log = discord.Embed(title="Log",color=discord.Colour.purple(), timestamp=ctx.message.created_at)
                log.add_field(name="Author:", value=f"{ctx.author.mention} [``{ctx.author.name}``]")
                log.add_field(name="Command:",value=f"*warn {member.mention} [``{member.name}``] {reason}")
                log.set_footer(icon_url=img,text="VersaBot")
                cursor = await self.bot.db.execute("SELECT logs_channel_id FROM main WHERE guild_id = ?", (ctx.guild.id,))
                data = await cursor.fetchone()
                channel = ctx.guild.get_channel(data[0])
                await channel.send(embed=log)
        else:
            embed2 = discord.Embed(description=f"**>** You do not have access to this command",color = discord.Colour.purple(),timestamp=ctx.message.created_at)
            embed2.set_footer(icon_url=img, text=f"VersaBot > {ctx.author.name}")
            await ctx.send(embed=embed2)

async def setup(bot):
      await bot.add_cog(warn(bot))
      print("-  " + versacolors.BLUE + "> " + versacolors.WHITE + "Command - Warn | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)