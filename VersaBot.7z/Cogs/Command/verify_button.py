import discord
from discord.ext import commands
from discord import ui
from Cogs.Utils.color import versacolors

dev_acces = 1046141237511585903
img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"

class verify(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def verifybutton(self, ctx):
        embed = discord.Embed(title="Verification", description="Press ✅ to verify yourself", color = discord.Colour.green())
        embed.set_footer(icon_url = img, text=f"VersaBot")
        await ctx.send(embed=embed, view = ui.View().add_item(ui.Button(label="✅", custom_id="verify",style= discord.ButtonStyle.green)))

async def setup(bot):
      await bot.add_cog(verify(bot))
      print("-  " + versacolors.BLUE + "> " + versacolors.WHITE + "Command - Verify | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)