import discord
from discord.ext import commands
from Cogs.Utils.color import versacolors

img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"


class poll(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def poll(self, ctx, *,message="None"):
        await ctx.message.delete()
        cursor = await self.bot.db.execute("SELECT ban_id FROM main WHERE guild_id = ?", (ctx.guild.id,))
        role_id = await cursor.fetchone()
        rola = discord.utils.get(ctx.guild.roles, id=role_id[0])
        if rola in ctx.author.roles:
            if message == "None":
                await ctx.send("Correct usage: ***poll <contents of the survey>**")
            else:
                embed = discord.Embed(title="Poll", description=message,color=discord.Colour.purple())
                embed.set_footer(icon_url=img, text="VersaBot")
                emsg = await ctx.send(embed=embed)
                await emsg.add_reaction('✅')
                await emsg.add_reaction('❌')
                log = discord.Embed(title="Log",color=discord.Colour.purple(), timestamp=ctx.message.created_at)
                log.add_field(name="Author:", value=f"{ctx.author.mention} [``{ctx.author.name}``]")
                log.add_field(name="Command:",value=f"*poll {message}")
                log.add_field(name="Channel:", value=ctx.channel.mention)
                log.set_footer(icon_url=img,text="VersaBot")
                cursor = await self.bot.db.execute("SELECT logs_channel_id FROM main WHERE guild_id = ?", (ctx.guild.id,))
                data = await cursor.fetchone()
                channel = ctx.guild.get_channel(data[0])
                await channel.send(embed=log)
        else:
            embed2 = discord.Embed(description=f"**>** You do not have access to this command",color = discord.Colour.purple(),timestamp=ctx.message.created_at)
            embed2.set_footer(icon_url =img, text=f"VersaBot > {ctx.author}")
            await ctx.send(embed=embed2)
            
async def setup(bot):
      await bot.add_cog(poll(bot))
      print("-  " + versacolors.BLUE + "> " + versacolors.WHITE + "Command - Poll | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)