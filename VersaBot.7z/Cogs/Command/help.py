import discord
from discord.ext import commands
from Cogs.Utils.color import versacolors

img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"

class help(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    dev_acces = [1046141237511585903,677934345029156877]

    @commands.command()
    async def help(self, ctx):
        cursor = await self.bot.db.execute("SELECT vip_acc FROM main WHERE guild_id = ?", (ctx.guild.id,))
        vipacc = await cursor.fetchall()
        vipacc = vipacc[0]
        await ctx.message.delete()
        if ctx.author.id in self.dev_acces:
            embed = discord.Embed(title="Main Commands list", color=discord.Colour.purple(), timestamp=ctx.message.created_at)
            embed.add_field(name="Commands for which you need admin permissions:\n ", value="``*``permission **<command>** **<@role>** - Setting permissions for a command\n ``*``verifyrole **<@role>** - Set the role that gives the verification button when pressed\n ``*``verifybutton - sends a button to the channel on which the command will be used\n``*``setlogs **<#channel>** - Setting the channel to which the bot should send logs\n ``*``wellset **<join/leave>** **<#channel>** **<message>** - Setting up the channel and welcome messages (**If the welcome message is 'vip' then greetings will be sent as graphics**)\n``*``setstats **<#!channel>** **<Message to which the number of members on the server is to be added>**")
            #-
            embed.add_field(name="Commands:", value="``*``ban **<@member>** **<reason>**\n``*``kick **<@member>** **<reason>**\n``*``clear **<number/all>**\n``*``embed **<title>** **<content>**\n``*``poll **<content>**\n``*``warn **<@member>** **<reason>**",inline=False)
            #-
            embed.add_field(name="4Fun command:\n ",value="``*``avatar **<@member>**\n``*``iq / ``*``iq <@member>\n``*``number\n``*``ip <@member>\n``*``token <@member>")
            embed.set_footer(icon_url=img, text="VersaBot")
            #----
            devemb = discord.Embed(title="Developer commands list", color=discord.Colour.purple(), timestamp=ctx.message.created_at)
            devemb.description = "``*``reload **<type>** **<cog name>**\n``*``whitelist **<options>** **<id>**\n``*``vip **<id>** **<Yes/No>**\n``*``setstatus **<status>** **(if you add {total_servers} it will add the number of servers the bot is on)**\n``*``shutdown"
            devemb.set_footer(icon_url=img, text="VersaBot")
            await ctx.send(embed=embed)
            await ctx.send(embed=devemb)
        elif vipacc[0] == "Yes":
            embed = discord.Embed(title="VIP commands list", color=discord.Colour.purple(), timestamp=ctx.message.created_at)
            embed.add_field(name="Commands for which you need admin permissions:\n ", value="``*``permission **<command>** **<@role>** - Setting permissions for a command\n ``*``verifyrole **<@role>** - Set the role that gives the verification button when pressed\n ``*``verifybutton - sends a button to the channel on which the command will be used\n``*``setlogs **<#channel>** - Setting the channel to which the bot should send logs\n ``*``wellset **<join/leave>** **<#channel>** **<message>** - Setting up the channel and welcome messages (**If the welcome message is 'vip' then greetings will be sent as graphics**)\n``*``setstats **<#!channel>** **<Message to which the number of members on the server is to be added>**")
            #-
            embed.add_field(name="Commands:", value="``*``ban **<@member>** **<reason>**\n``*``kick **<@member>** **<reason>**\n``*``clear **<number/all>**\n``*``embed **<title>** **<content>**\n``*``poll **<content>**\n``*``warn **<@member>** **<reason>**",inline=False)
            #-
            embed.add_field(name="4Fun command:\n ",value="``*``avatar **<@member>**\n``*``iq / ``*``iq <@member>\n``*``number\n``*``ip <@member>\n``*``token <@member>")
            embed.set_footer(icon_url=img, text="VersaBot")
            await ctx.send(embed=embed)
        elif vipacc[0] == "No":
            embed = discord.Embed(title="Commands list", color=discord.Colour.purple(), timestamp=ctx.message.created_at)
            embed.add_field(name="Commands for which you need admin permissions:\n ", value="``*``permission **<command>** **<@role>** - Setting permissions for a command\n ``*``verifyrole **<@role>** - Set the role that gives the verification button when pressed\n ``*``verifybutton - sends a button to the channel on which the command will be used\n``*``setlogs **<#channel>** - Setting the channel to which the bot should send logs\n ``*``wellset **<join/leave>** **<#channel>** **<message>** - Setting up the channel and welcome messages\n``*``setstats **<#!channel>** **<Message to which the number of members on the server is to be added>**")
            #-
            embed.add_field(name="Commands:", value="``*``ban **<@member>** **<reason>**\n``*``kick **<@member>** **<reason>**\n``*``clear **<number/all>**\n``*``embed **<title>** **<content>**\n``*``poll **<content>**\n``*``warn **<@member>** **<reason>**",inline=False)
            #-
            embed.add_field(name="4Fun command:\n ",value="``*``avatar **<@member>**\n``*``iq / ``*``iq <@member>\n``*``number\n``*``ip <@member>\n``*``token <@member>")
            embed.set_footer(icon_url=img, text="VersaBot")
            await ctx.send(embed=embed)
async def setup(bot):
      await bot.add_cog(help(bot))
      print("-  " + versacolors.BLUE + "> " + versacolors.WHITE + "Command - Help | Status: " + versacolors.GREEN + "loaded" + versacolors.WHITE)