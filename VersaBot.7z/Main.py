import discord
from discord.ext import commands
import aiosqlite
import logging
from datetime import datetime
import json
from Cogs.Utils.color import versacolors

intents = discord.Intents.default()
intents.members = True
intents.presences = True
intents.message_content = True
intents.guilds = True

logger = logging.getLogger('discord')
logger.setLevel(logging.DEBUG)
log_file_name = f'logs/bot_logs( {datetime.now().strftime("%Y.%m.%d_%H.%M")} ).log'
handler = logging.FileHandler(filename=log_file_name, encoding='utf-8', mode='w')
handler.setFormatter(logging.Formatter('%(asctime)s:%(levelname)s:%(name)s: %(message)s'))
logger.addHandler(handler)

bot = commands.Bot(command_prefix="*", intents=intents)
bot.remove_command("help")

img = "https://cdn.discordapp.com/attachments/1169312630398271572/1199082018215043213/versa-logo.png?ex=65c13f27&is=65aeca27&hm=26744b5c9fc413f5fea358631fb23888b4e40fa6103b775958617e069e57a520&"
dev_acces = [1046141237511585903,677934345029156877]
terminal_channel = 1200036203450347541
status_file = 'status.json'
bot.launch_time = datetime.utcnow()
total_servers = len(bot.guilds)

@bot.event
async def on_ready():
    print("Code by 3DV (dc: 3dv_als, github: https://github.com/VersaIndustries)")
    print("\n __      __                     _           _           _        _                _   _______ _____   ")
    print(" \ \    / /                    (_)         | |         | |      (_)              | | |__   __|  __ \  ")
    print("  \ \  / /__ _ __ ___  __ _     _ _ __   __| |_   _ ___| |_ _ __ _  ___  ___     | |    | |  | |  | | ")
    print("   \ \/ / _ \ '__/ __|/ _` |   | | '_ \ / _` | | | / __| __| '__| |/ _ \/ __|    | |    | |  | |  | | ")
    print("    \  /  __/ |  \__ \ (_| |   | | | | | (_| | |_| \__ \ |_| |  | |  __/\__ \    | |____| |  | |__| | ")
    print("     \/ \___|_|  |___/\__,_|   |_|_| |_|\__,_|\__,_|___/\__|_|  |_|\___||___/    |______|_|  |_____(_)")
    print('\nLogged in as:\n{0.user.name}\n{0.user.id}'.format(bot))
    print("\n --- \n")
    with open(status_file, 'r') as file:
        status_data = json.load(file)
        await bot.change_presence(activity=discord.Game(name=status_data['status'].replace("{total_servers}", str(len(bot.guilds)))))
    try:
        bot.db = await aiosqlite.connect("database.db")
        await bot.db.execute(
            """
            CREATE TABLE IF NOT EXISTS main(
                guild_id INT,
                vip_acc VARCHAR(3),
                logs_channel_id INT,
                stats_channel_id INT,
                ban_id INT,
                kick_id INT,
                clear_id INT,
                warn_id INT,
                poll_id INT,
                embed_id INT,
                join_channel_id INT,
                leave_channel_id INT,
                join_message VARCHAR(1250),
                leave_message VARCHAR(1250),
                verify_role_id INT,
                PRIMARY KEY (guild_id)
            )
            """
        )
        await bot.db.commit()
        print(versacolors.YELLOW + "> " + versacolors.WHITE + "Database | Status: " + versacolors.GREEN + "connected" + versacolors.WHITE) 
    except Exception as e:
        print(versacolors.YELLOW + "> " + versacolors.WHITE + "Database | Status: " + versacolors.RED + "Disconnected" + versacolors.WHITE)
    print("\n --- \n ") 
    #extensions
    try:
        await bot.load_extension("Cogs.core")
    except Exception as e:
        print(versacolors.CYAN + "> " + versacolors.WHITE + "Module - Core | Status: " + versacolors.RED + "Failed" + versacolors.WHITE)
#console-log
@bot.event
async def on_command_error(ctx, error):
    channel = bot.get_channel(1200036203450347541)
    if isinstance(error, commands.CommandNotFound):
        await ctx.send(f"{ctx.author.mention} Command does not exist ")
    else:
        await channel.send(f"<@1046141237511585903>\n{ctx.guild.name} [``{ctx.guild.id}``] - ctx guild\n{ctx.author.mention} [``{ctx.author.name}``] - ctx author\nCommand: **{ctx.message.content}**\n```py\n{error}```")
    
@bot.command()
async def reload(ctx, type = "None" ,name="None"):
    if ctx.author.id in dev_acces:
        if type == "None":
            await ctx.send("dostepne foldery: Listeners, Command")
        else:
            if type == "listener":
                if name == "None":
                    await ctx.send("poprawne uzycie:")
                await bot.reload_extension("Cogs.Listener."+name)
                await ctx.send(f"**>** Listner ``{name}`` reload  **|**")
            if type == "command":
                if name == "None":
                    await ctx.send("poprawne uzycie:")
                await bot.reload_extension("Cogs.Command."+name)
                await ctx.send(f"**>** Commands ``{name}`` reload  **|**")
            if type == "funcommand":
                if name == "None":
                    await ctx.send("poprawne uzycie:")
                await bot.reload_extension("Cogs.Command4Fun."+name)
                await ctx.send(f"**>** 4Fun Commands ``{name}`` reload  **|**")
            if type == "devplatform":
                if name == "None":
                    await ctx.send("poprawne uzycie:")
                await bot.reload_extension("Cogs.DevPlatform."+name)
                await ctx.send(f"**>** DevPlatform cog ``{name}`` reload  **|**")
            if type == "module":
                if name == "None":
                    await ctx.send("poprawne uzycie:")
                await bot.reload_extension("Cogs."+name)
                await ctx.send(f"**>** Module ``{name}`` reload  **|**")
    else:
        embed2 = discord.Embed(color = discord.Colour.dark_blue(),timestamp=ctx.message.created_at)
        embed2.set_footer(icon_url = "", text=f"{ctx.author.name} This command is only available to the bot developer\n VersaBot")
        await ctx.send(embed=embed2)

@bot.command()
async def extlist(ctx):
    if ctx.author.id in dev_acces:
        loaded_extensions = bot.extensions.keys()
        listener_extensions = []
        command_extensions = []
        devplatform_extensions = []

        for extension in loaded_extensions:
            clean_extension = extension.replace("Cogs.Listener.", "").replace("Cogs.Command.", "").replace("Cogs.DevPlatform.", "")
            if extension.startswith("Cogs.Listener."):
                listener_extensions.append(f" ≫ ``{clean_extension}``")
            elif extension.startswith("Cogs.Command."):
                command_extensions.append(f" ≫ ``{clean_extension}``")
            elif extension.startswith("Cogs.DevPlatform."):
                devplatform_extensions.append(f" ≫ ``{clean_extension}``")

        embed = discord.Embed(title="Loaded Extensions", color=discord.Color.purple(),timestamp=ctx.message.created_at)

        if command_extensions:
            embed.add_field(name="Command", value="\n".join(command_extensions), inline=False)
        else:
            embed.add_field(name="Command", value="No extensions loaded", inline=False)
        await ctx.send(embed=embed)

        if listener_extensions:
            embed.add_field(name="Listeners", value="\n".join(listener_extensions), inline=False)
        else:
            embed.add_field(name="Listeners", value="No extensions loaded", inline=False)

        if devplatform_extensions:
            embed.add_field(name="DevPlatform", value="\n".join(devplatform_extensions), inline=False)
        else:
            embed.add_field(name="DevPlatform", value="No extensions loaded", inline=False)
        embed.set_footer(icon_url=img, text="VersaBot")
        await ctx.send(embed=embed)
    else:
        embed2 = discord.Embed(color = discord.Colour.dark_red(),timestamp=ctx.message.created_at)
        embed2.set_footer(icon_url =img, text=f"{ctx.author.name} This command is only available to the bot developer\n VersaBot")
        await ctx.message.delete()
        await ctx.send(embed=embed2)


@bot.command()
async def shutdown(ctx):
    if ctx.author.id in dev_acces:
        embed = discord.Embed(color = discord.Colour.purple(),timestamp=ctx.message.created_at)
        embed.set_footer(icon_url = img, text=f"bot has been deactivated \n VersaBot")
        await ctx.message.delete() 
        await ctx.send(embed=embed) 
        await bot.close()
    else:
        embed2 = discord.Embed(color = discord.Colour.purple(),timestamp=ctx.message.created_at)
        embed2.set_footer(icon_url =img, text=f"{ctx.author.name} You wanted to disable the bot hahah, not this time this command is only available to the bot developer\n VersaBot")
        await ctx.send(embed=embed2)

logger.removeHandler(handler)

bot.run("")